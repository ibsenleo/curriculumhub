import { createAction } from "@reduxjs/toolkit";

export const clearStateAction = createAction('clearStateAction')