export const authStatus = {
    LOGGED: 'logged',
    NOT_LOGGED: 'not-logged',
    LOGGING: 'logging'
}