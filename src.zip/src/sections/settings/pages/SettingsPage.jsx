import React from 'react'

export const SettingsPage = () => {
  return (
    <div>SettingsPage</div>
  )
}
